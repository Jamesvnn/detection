% clc; clear; close all; tic
% =========================================================================
% dirname = 'images';
% filename = 'DJI_0197.JPG';
% =========================================================================
load('o.mat')
% --------Determining anchor boxes
% anchorBoxes = [8,8;32,48;40,24;72,48]; % default anchor boxes
anchorBoxes = [112,118;24,84;76,76;92,92;75,30;98,67;132,128;95,46;37,89;...
    47,96;88,83;65,58;103,108;112,99;97,124;117,133;120,111;101,97;87,102;64,104];
cnt = size(anchorBoxes, 1);
% --------options
% 'sgdm' | 'rmsprop' | 'adam'
options = trainingOptions('sgdm',...
          'InitialLearnRate',1e-3,...
          'Verbose',true,...
          'MiniBatchSize',16,...
          'MaxEpochs',100,...
          'Shuffle','every-epoch',...
          'VerboseFrequency',30);
%           'CheckpointPath','temp');
layers = [
    imageInputLayer([224 224 3],"Name","input","Normalization","none")
    convolution2dLayer([3 3],16,"Name","conv_1","Padding",[1 1 1 1],"WeightsInitializer","narrow-normal")
    batchNormalizationLayer("Name","BN1")
    reluLayer("Name","relu_1")
    maxPooling2dLayer([2 2],"Name","maxpool1","Stride",[2 2])
    convolution2dLayer([3 3],32,"Name","conv_2","Padding",[1 1 1 1],"WeightsInitializer","narrow-normal")
    batchNormalizationLayer("Name","BN2")
    reluLayer("Name","relu_2")
    maxPooling2dLayer([2 2],"Name","maxpool2","Stride",[2 2])
    convolution2dLayer([3 3],64,"Name","conv_3","Padding",[1 1 1 1],"WeightsInitializer","narrow-normal")
    batchNormalizationLayer("Name","BN3")
    reluLayer("Name","relu_3")
    maxPooling2dLayer([2 2],"Name","maxpool3","Stride",[2 2])
    convolution2dLayer([3 3],128,"Name","conv_4","Padding",[1 1 1 1],"WeightsInitializer","narrow-normal")
    batchNormalizationLayer("Name","BN4")
    reluLayer("Name","relu_4")
    convolution2dLayer([3 3],128,"Name","yolov2Conv1","Padding","same","WeightsInitializer","narrow-normal")
    batchNormalizationLayer("Name","yolov2Batch1")
    reluLayer("Name","yolov2Relu1")
    convolution2dLayer([3 3],128,"Name","yolov2Conv2","Padding","same","WeightsInitializer","narrow-normal")
    batchNormalizationLayer("Name","yolov2Batch2")
    reluLayer("Name","yolov2Relu2")
    convolution2dLayer([1 1],cnt*(5+2),"Name","yolov2ClassConv","WeightsInitializer","narrow-normal")
    yolov2TransformLayer(cnt,"Name","yolov2Transform")
    yolov2OutputLayer(anchorBoxes, "Name", "yolov2OutputLayer")];

lgraph = layerGraph(layers);

% [detector, info] = trainYOLOv2ObjectDetector(o, lgraph, options);

% 86, 88-92
% 94-97
% 100, 101, 104, 106
% 108-114
% 117-120% 122-144

n = 12;
part = 12;
for i = (part*n):-1:((part - 1)*n + 1)
    filename = ['images/_original/', num2str(i), '.JPG'];
    img = imread(filename);
    [bbox, score, label] = detect(detector, img);
    o_box = bbox(label == 'o', :);
    n_box = bbox(label == 'n', :);
    score_str = cellfun(@(c)[c '%'],cellstr(num2str(score*100, '%0.1f')),'UniformOutput',false);
    if ~isempty(o_box)
        img = insertObjectAnnotation(img, 'rectangle', o_box, ...
            score_str(label == 'o'), 'LineWidth', 3,'Color', 'r');
    end
    
    if ~isempty(n_box)
        img = insertObjectAnnotation(img, 'rectangle', n_box, ...
            score_str(label == 'n'), 'LineWidth', 3,'Color', 'blue');
    end
    figure; imshow(img); title([num2str(i), '.JPG'])

end

figure
plot(info.TrainingLoss)
xlabel('iteration')
ylabel('loss function')
title('loss function')

figure
plot(info.TrainingRMSE)
xlabel('iteration')
ylabel('RMSE')
title('RMSE')

figure
plot(info.BaseLearnRate)
xlabel('iteration')
ylabel('BaseLearnRate')
title('BaseLearnRate')


% =========================================================================
t = toc;
save('yolov2_res_224rmsprop')

% =========================================================================





