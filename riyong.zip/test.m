clc
close all
clear

data = load('fasterRCNNVehicleTrainingData.mat');

trainingData = data.vehicleTrainingData;

trainingData.imageFilename = fullfile(toolboxdir('vision'),'visiondata', ...
    trainingData.imageFilename);

layers = data.layers

options = trainingOptions('sgdm', ...
      'MiniBatchSize', 1, ...
      'InitialLearnRate', 1e-3, ...
      'MaxEpochs', 5, ...
      'VerboseFrequency', 200, ...
      'CheckpointPath', tempdir);
% detector = trainFasterRCNNObjectDetector(trainingData, layers, options);

img = imread('highway.png');

[bbox, score, label] = detect(detector, img);

detectedImg = insertShape(img, 'Rectangle', bbox);
figure
imshow(detectedImg)

